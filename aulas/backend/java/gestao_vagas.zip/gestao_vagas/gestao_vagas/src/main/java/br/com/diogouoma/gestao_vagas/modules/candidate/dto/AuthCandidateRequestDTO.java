package br.com.diogouoma.gestao_vagas.modules.candidate.dto;

public record AuthCandidateRequestDTO(
        String username,
        String password
) {
}
