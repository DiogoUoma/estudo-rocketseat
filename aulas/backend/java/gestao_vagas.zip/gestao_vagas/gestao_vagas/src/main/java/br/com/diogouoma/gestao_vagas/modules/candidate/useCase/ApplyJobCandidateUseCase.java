package br.com.diogouoma.gestao_vagas.modules.candidate.useCase;

import org.springframework.stereotype.Service;

@Service
public class ApplyJobCandidateUseCase {

    //Id candidato
    //id da vaga
    public void execute() {
        
    }

}
